# Authors

## Maintainer

Geoffrey Fairchild
* [https://www.gfairchild.com/](https://www.gfairchild.com/)
* [https://github.com/gfairchild](https://github.com/gfairchild)
* [https://www.linkedin.com/in/gfairchild/](https://www.linkedin.com/in/gfairchild/)

## Contributors

Sorted by date of first contribution:

* [goodspark](https://github.com/goodspark)
* [davebulaval](https://github.com/davebulaval)
